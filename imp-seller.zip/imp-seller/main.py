import disnake
from disnake.ext import commands, tasks
import os

# Определяем необходимые идентификаторы
TICKET_CATEGORY_ID = 1269167310669615105
CHANNEL_ID_1 = 1269168250730713180
REVIEW_CHANNEL_ID = 1269160387685646458
REVIEW_ROLE_ID = 1269179019195060225
LOG_CHANNEL_ID = 1269185884578910228
CHANNEL_ID_2 = 1269017908046991401
MESSAGE_ID_FILE_1 = 'message_id_1.txt'
LAST_MESSAGE_ID_FILE = 'last_message_id.txt'
TICKET_LOG_DIR = 'ticket_logs'

# Настройка разрешений и намерений
intents = disnake.Intents.default()
intents.messages = True
intents.guilds = True
intents.members = True
intents.message_content = True

# Инициализация бота
bot = commands.Bot(command_prefix='!', intents=intents)

# Создаем директории для логов тикетов, если их нет
os.makedirs(TICKET_LOG_DIR, exist_ok=True)

# Функции для работы с файлами и логами
def save_message_id(file_path, message_id):
    with open(file_path, 'w') as f:
        f.write(str(message_id))

def load_message_id(file_path):
    if os.path.exists(file_path):
        with open(file_path, 'r') as f:
            return int(f.read().strip())
    return None

# Основные функции для тикетов
async def log_ticket_action(action, ticket_channel, member, log_file_path=None):
    log_channel = bot.get_channel(LOG_CHANNEL_ID)
    if log_channel:
        embed = disnake.Embed(
            title="Лог тикета",
            description=f"{action} тикет",
            color=disnake.Color.blue()
        )
        embed.add_field(name="Канал тикета", value=ticket_channel.mention)
        embed.add_field(name="Пользователь", value=member.mention)
        if log_file_path:
            view = disnake.ui.View(timeout=None)  # Установка timeout=None
            button = disnake.ui.Button(label="Посмотреть сообщения", style=disnake.ButtonStyle.blurple)

            async def button_callback(interaction):
                await interaction.response.send_message(file=disnake.File(log_file_path), ephemeral=True)

            button.callback = button_callback
            view.add_item(button)

            await log_channel.send(embed=embed, view=view)
        else:
            await log_channel.send(embed=embed)

async def delete_all_messages(channel):
    async for message in channel.history(limit=None):
        try:
            await message.delete()
        except disnake.Forbidden:
            print("У бота нет прав для удаления сообщений в этом канале.")
        except disnake.NotFound:
            pass

async def send_ticket_message(channel):
    await delete_all_messages(channel)

    button = disnake.ui.Button(label="Создать тикет", style=disnake.ButtonStyle.green)

    async def button_callback(interaction):
        guild = interaction.guild
        member = interaction.user

        category = disnake.utils.get(guild.categories, id=TICKET_CATEGORY_ID)

        if not category:
            await interaction.response.send_message(
                "Не удалось найти категорию для тикетов. Обратитесь к администратору.", ephemeral=True)
            return

        overwrites = {
            guild.default_role: disnake.PermissionOverwrite(read_messages=False),
            member: disnake.PermissionOverwrite(read_messages=True, send_messages=True)
        }

        try:
            ticket_channel = await category.create_text_channel(name=f"тикет-{member.display_name}", overwrites=overwrites)
            await send_ticket_channel_message(ticket_channel, member)
            await log_ticket_action("Создан", ticket_channel, member)

            await interaction.response.send_message(f"Канал для тикета создан: {ticket_channel.mention}", ephemeral=True)
        except Exception as e:
            await interaction.response.send_message("Произошла ошибка при создании канала тикета. Попробуйте еще раз позже.", ephemeral=True)
            print(f"Ошибка при создании канала тикета: {e}")

    button.callback = button_callback

    view = disnake.ui.View(timeout=None)
    view.add_item(button)

    embed = disnake.Embed(color=disnake.Color.from_rgb(32, 24, 37))
    embed.set_image(
        url="https://cdn.discordapp.com/attachments/1269154338526330923/1269283048348979240/anime_girls_long_hair_nekomimi_THE_email_protected_Shibuya_Rin1-1355275.png?ex=66af7f74&is=66ae2df4&hm=bdbd38ee088193ece433093e2caff46356e1da168d7efd0a51888b677bc17cff&")

    message = await channel.send(embed=embed, view=view)
    save_message_id(MESSAGE_ID_FILE_1, message.id)
    print(f"Сообщение отправлено в канал {channel.name} с ID {message.id}")
    return message.id

async def send_ticket_channel_message(ticket_channel, member):
    close_button = disnake.ui.Button(label="Закрыть тикет", style=disnake.ButtonStyle.red)
    review_button = disnake.ui.Button(label="Отправить отзыв", style=disnake.ButtonStyle.green)

    async def close_button_callback(interaction):
        if interaction.user == member or interaction.user.guild_permissions.administrator:
            messages = await ticket_channel.history(limit=100).flatten()
            log_file_path = os.path.join(TICKET_LOG_DIR, f"ticket_{ticket_channel.id}.txt")

            with open(log_file_path, 'w', encoding='utf-8') as file:
                for msg in messages:
                    file.write(f"{msg.author}: {msg.content}\n")

            await log_ticket_action("Удален", ticket_channel, member, log_file_path)
            await ticket_channel.delete()
            await interaction.response.send_message("Тикет закрыт.", ephemeral=True)
        else:
            await interaction.response.send_message("Вы не можете закрыть этот тикет.", ephemeral=True)

    async def review_button_callback(interaction):
        if interaction.user.id == member.id:
            role = disnake.utils.get(interaction.guild.roles, id=REVIEW_ROLE_ID)
            if role in member.roles:
                review_channel = bot.get_channel(REVIEW_CHANNEL_ID)
                review_channel_url = review_channel.jump_url
                await interaction.response.send_message(
                    f"Перейдите в канал для отзывов по следующей ссылке: {review_channel_url}", ephemeral=True)
            else:
                await interaction.response.send_message("У вас нет необходимой роли для отправки отзыва.",
                                                        ephemeral=True)

    view = disnake.ui.View(timeout=None)  # Установка timeout=None
    close_button.callback = close_button_callback
    review_button.callback = review_button_callback
    view.add_item(close_button)
    view.add_item(review_button)

    await ticket_channel.send(
        f"{member.mention}, вы можете написать свой заказ либо ознакомиться с товарами тут https://discord.com/channels/1210713575778160712/1269017908046991401. После выполнения заказа вы получите роль покупателя и сможете оставить отзыв",
        view=view)


async def send_main_message(channel):
    """Отправляет новое сообщение с кнопками в указанный канал и удаляет предыдущее."""
    await delete_all_messages(channel)

    view = disnake.ui.View(timeout=None)

    buttons = {
        "Osint Tool": ["https://cdn.discordapp.com/attachments/1269154338526330923/1269321326657802370/OsintTool.png?ex=66afa31b&is=66ae519b&hm=4103fa34454e1b0670ebd4a198eadc94697a5a5a08c7868f8c39ca896a819fc6&"],
        "TG Premium": ["https://cdn.discordapp.com/attachments/1269154338526330923/1269337157747736576/TgPremyer.png?ex=66afb1d9&is=66ae6059&hm=d2642d48177614fc6782fb26c0231460c7481d7e8d264acfbc15b9c952763777&"],
        "Discord Nitro": ["https://cdn.discordapp.com/attachments/1269154338526330923/1269337758581788753/FullNitro.png?ex=66afb268&is=66ae60e8&hm=5cf189db7eedf41cccb9a58db80de38e21a24a21010cffd9f79e2135a54ad527&"],
        "Minecrf License Java+Bedrock": ["https://cdn.discordapp.com/attachments/1269154338526330923/1269319253140701295/Minecraft.png?ex=66afa12c&is=66ae4fac&hm=eb78705bfbc11d6fd47e2adaf36c83ccebb306fa5ccee4b475040f5ec02d6770&"],
        "MullvadVPN": ["https://cdn.discordapp.com/attachments/1269154338526330923/1269319615021056010/MullvadVPN.png?ex=66afa183&is=66ae5003&hm=f398d0512eb4c605f8f189c74cd32455646f2458f8b2ee96b2a87793ee1c6d03&"],
        "PureVPN": ["https://cdn.discordapp.com/attachments/1269154338526330923/1269319808122355874/PureVPN.png?ex=66afa1b1&is=66ae5031&hm=a52f3772f2f0001b59c49bd8b2d9a5023266c6e8501261cd3191b5821d1e383c&"],
        "Discord - Tokens": ["https://cdn.discordapp.com/attachments/1269154338526330923/1269319982035243040/DSTokens.png?ex=66afa1da&is=66ae505a&hm=8d1ffd67d083d48036f3283cf30e6a4fb79b03f09b39cb7332cff690ebb2c384&"],
        "Шаблон для сервера": ["https://cdn.discordapp.com/attachments/1269154338526330923/1269320535444295701/Shablon.png?ex=66afa25e&is=66ae50de&hm=9694cd2015d8e52770819f2f4f7663fdafc114872fd0756849bc15ea3b713239&"],
        "Anti Crash-bot": ["https://cdn.discordapp.com/attachments/1269154338526330923/1269320682810900600/AntiCrashBOT.png?ex=66afa281&is=66ae5101&hm=0899a760a3f0b325f41fb51ca6a9418f7e65c22e95d7dc7cfebab02dfcf57b64&"],
        "Discord-Tool": ["https://cdn.discordapp.com/attachments/1269154338526330923/1269321023707152404/DiscordTool.png?ex=66afa2d2&is=66ae5152&hm=bd7188114045adc81b56da4f1d54e558494063eb967425030483911336c6e2f5&"],
        "Spotify Premium": ["https://cdn.discordapp.com/attachments/1269154338526330923/1269336147507810446/SpotifyPremAcc.png?ex=66afb0e8&is=66ae5f68&hm=837756799e955a25e80a95519962c363fe451540d9cdd941c1b7e12f5cb39887&"],
        "Telegram Account": ["https://cdn.discordapp.com/attachments/1269154338526330923/1269336801785679993/TelegrammAutoREg.png?ex=66afb184&is=66ae6004&hm=a92eec6e217650ede6801939644646e5b018b15ba6262bece207cd43134fa13e&"]
    }


    for label, image_urls in buttons.items():
        button = disnake.ui.Button(label=label, style=disnake.ButtonStyle.green)

        async def button_callback(interaction, image_urls=image_urls):
            # Отправляем первый ответ с подтверждением
            await interaction.response.send_message("Загружаю изображения...", ephemeral=True)

            # Отправляем остальные изображения через followup.send
            for url in image_urls:
                embed = disnake.Embed(color=disnake.Color.from_rgb(32, 24, 37))
                embed.set_image(url=url)
                await interaction.followup.send(embed=embed, ephemeral=True)

        button.callback = button_callback
        view.add_item(button)

    embed = disnake.Embed(color=disnake.Color.blue())
    embed.set_image(
        url="https://cdn.discordapp.com/attachments/1269154338526330923/1269283048713748500/anime_girls_long_hair_nekomimi_THE_email_protected_Shibuya_Rin-1355275123.png?ex=66af7f74&is=66ae2df4&hm=bfae5633a7743516699746f74874872d763352289c2613ea2374fa45e2ba4cc5&")

    try:
        message = await channel.send(embed=embed, view=view)
        save_message_id(LAST_MESSAGE_ID_FILE, message.id)
        print(f"Сообщение отправлено в канал {channel.name} с ID {message.id}")
    except Exception as e:
        print(f"Ошибка при отправке сообщения в канал {channel.id}: {e}")

# Задача для обновления сообщений каждые 5 минут
@tasks.loop(minutes=5)
async def update_messages():
    channel_1 = bot.get_channel(CHANNEL_ID_1)
    if channel_1:
        message_id_1 = load_message_id(MESSAGE_ID_FILE_1)
        if message_id_1:
            try:
                message = await channel_1.fetch_message(message_id_1)
                if message:
                    await message.delete()
            except disnake.NotFound:
                pass
        message_id_1 = await send_ticket_message(channel_1)
        save_message_id(MESSAGE_ID_FILE_1, message_id_1)
    else:
        print(f"Channel with ID {CHANNEL_ID_1} not found.")

    channel_2 = bot.get_channel(CHANNEL_ID_2)
    if channel_2:
        last_message_id = load_message_id(LAST_MESSAGE_ID_FILE)
        if last_message_id:
            try:
                message = await channel_2.fetch_message(last_message_id)
                if message:
                    await message.delete()
            except disnake.NotFound:
                pass
        await send_main_message(channel_2)
    else:
        print(f"Channel with ID {CHANNEL_ID_2} not found.")

@bot.event
async def on_ready():
    print(f"Logged in as {bot.user} (ID: {bot.user.id})")
    update_messages.start()

bot.run("MTI2ODk0NjYxNTE0NjkwNTYxMA.GuOgtp.nRMewdtVAsIlVacJ6EB2Waw5NpeuORNe7ynJNw")
