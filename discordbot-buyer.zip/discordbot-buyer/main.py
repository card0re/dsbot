import disnake
from disnake.ext import commands, tasks
import os

intents = disnake.Intents.default()
intents.messages = True
intents.guilds = True
intents.members = True
intents.message_content = True

bot = commands.Bot(command_prefix='!', intents=intents)

TICKET_CATEGORY_ID = 1269167310669615105
ADMIN_ROLE_ID = 1244881996753408041
CHANNEL_ID = 1269168250730713180
REVIEW_CHANNEL_ID = 1269160387685646458
REVIEW_ROLE_ID = 1269179019195060225
LOG_CHANNEL_ID = 1269185884578910228
MESSAGE_ID_FILE = 'message_id.txt'
TICKET_LOG_DIR = 'ticket_logs'

os.makedirs(TICKET_LOG_DIR, exist_ok=True)

open_tickets = {}

def save_message_id(message_id):
    with open(MESSAGE_ID_FILE, 'w') as f:
        f.write(str(message_id))

def load_message_id():
    if os.path.exists(MESSAGE_ID_FILE):
        with open(MESSAGE_ID_FILE, 'r') as f:
            return int(f.read().strip())
    return None

async def log_ticket_action(action, ticket_channel, member, log_file_path=None):
    log_channel = bot.get_channel(LOG_CHANNEL_ID)
    if log_channel:
        embed = disnake.Embed(
            title="Лог тикета",
            description=f"{action} тикет",
            color=disnake.Color.blue()
        )
        embed.add_field(name="Канал тикета", value=ticket_channel.mention)
        embed.add_field(name="Пользователь", value=member.mention)
        if log_file_path:
            view = disnake.ui.View()
            button = disnake.ui.Button(label="Посмотреть сообщения", style=disnake.ButtonStyle.blurple)

            async def button_callback(interaction):
                await interaction.response.send_message(file=disnake.File(log_file_path), ephemeral=True)

            button.callback = button_callback
            view.add_item(button)

            await log_channel.send(embed=embed, view=view)
        else:
            await log_channel.send(embed=embed)

async def send_ticket_message(channel):
    button = disnake.ui.Button(label="Создать тикет", style=disnake.ButtonStyle.green)

    async def button_callback(interaction):
        guild = interaction.guild
        member = interaction.user

        if member.id in open_tickets:
            await interaction.response.send_message(
                f"У вас уже есть открытый тикет: {open_tickets[member.id]['channel'].mention}", ephemeral=True)
            return

        category = disnake.utils.get(guild.categories, id=TICKET_CATEGORY_ID)

        if not category:
            category = await guild.create_category(name="Тикеты")

        overwrites = {
            guild.default_role: disnake.PermissionOverwrite(read_messages=False),
            member: disnake.PermissionOverwrite(read_messages=True, send_messages=True),
            guild.get_role(ADMIN_ROLE_ID): disnake.PermissionOverwrite(read_messages=True, send_messages=True)
        }

        ticket_channel = await category.create_text_channel(name=f"тикет-{member.display_name}", overwrites=overwrites)
        open_tickets[member.id] = {'channel': ticket_channel, 'messages': []}

        await send_ticket_channel_message(ticket_channel, member)
        await log_ticket_action("Создан", ticket_channel, member)

        await interaction.response.send_message(f"Канал для тикета создан: {ticket_channel.mention}", ephemeral=True)

    button.callback = button_callback

    view = disnake.ui.View()
    view.add_item(button)

    embed = disnake.Embed(color=disnake.Color.from_rgb(32, 24, 37))
    embed.set_image(
        url="https://cdn.discordapp.com/attachments/1269154338526330923/1269172495756300409/7c1dc86e5a2864ab.png?ex=66af187f&is=66adc6ff&hm=c5cb08119b769936a55681793a044eee0837394c215b1cd3d2e2e00307575f44&")

    message = await channel.send(embed=embed, view=view)
    save_message_id(message.id)
    print(f"Сообщение отправлено в канал {channel.name} с ID {message.id}")
    return message.id

async def send_ticket_channel_message(ticket_channel, member):
    close_button = disnake.ui.Button(label="Закрыть тикет", style=disnake.ButtonStyle.red)
    review_button = disnake.ui.Button(label="Отправить отзыв", style=disnake.ButtonStyle.green)

    async def close_button_callback(interaction):
        if interaction.user == member or interaction.user.guild_permissions.administrator:
            # Получаем все сообщения из тикета
            messages = await ticket_channel.history(limit=100).flatten()
            log_file_path = os.path.join(TICKET_LOG_DIR, f"ticket_{ticket_channel.id}.txt")

            with open(log_file_path, 'w', encoding='utf-8') as file:
                for msg in messages:
                    file.write(f"{msg.author}: {msg.content}\n")

            await log_ticket_action("Удален", ticket_channel, member, log_file_path)
            await ticket_channel.delete()
            del open_tickets[member.id]
            await interaction.response.send_message("Тикет закрыт.", ephemeral=True)
        else:
            await interaction.response.send_message("Вы не можете закрыть этот тикет.", ephemeral=True)

    async def review_button_callback(interaction):
        if interaction.user.id == member.id:
            role = disnake.utils.get(interaction.guild.roles, id=REVIEW_ROLE_ID)
            if role in member.roles:
                review_channel = bot.get_channel(REVIEW_CHANNEL_ID)
                review_channel_url = review_channel.jump_url
                await interaction.response.send_message(
                    f"Перейдите в канал для отзывов по следующей ссылке: {review_channel_url}", ephemeral=True)
            else:
                await interaction.response.send_message("У вас нет необходимой роли для отправки отзыва.",
                                                        ephemeral=True)

    close_button.callback = close_button_callback
    review_button.callback = review_button_callback

    view = disnake.ui.View()
    view.add_item(close_button)
    view.add_item(review_button)

    await ticket_channel.send(
        f"{member.mention}, вы можете написать свой заказ либо ознакомиться с товарами тут https://discord.com/channels/1210713575778160712/1269017908046991401. После выполнения заказа вы получите роль покупателя и сможете оставить отзыв",
        view=view)

@bot.event
async def on_message(message):
    if message.author == bot.user:
        return

    if message.channel.category and message.channel.category.id == TICKET_CATEGORY_ID:
        for ticket in open_tickets.values():
            if message.channel.id == ticket['channel'].id:
                ticket['messages'].append(message)
                log_file_path = os.path.join(TICKET_LOG_DIR, f"ticket_{message.channel.id}.txt")
                with open(log_file_path, 'a', encoding='utf-8') as file:
                    file.write(f"{message.author}: {message.content}\n")

@bot.event
async def on_ready():
    print(f"Бот {bot.user} готов к работе!")
    channel = bot.get_channel(CHANNEL_ID)
    if channel:
        message_id = load_message_id()
        if message_id:
            try:
                old_message = await channel.fetch_message(message_id)
                await old_message.delete()
                print(f"Старое сообщение удалено: {message_id}")
            except disnake.NotFound:
                print("Старое сообщение не найдено")

        new_message_id = await send_ticket_message(channel)
        save_message_id(new_message_id)
        check_message_exists.start()

@tasks.loop(seconds=30)
async def check_message_exists():
    channel = bot.get_channel(CHANNEL_ID)
    if channel:
        message_id = load_message_id()
        if message_id:
            try:
                await channel.fetch_message(message_id)
                print("Сообщение существует и работает корректно")
            except disnake.NotFound:
                print("Сообщение не найдено, отправка нового сообщения")
                new_message_id = await send_ticket_message(channel)
                save_message_id(new_message_id)
        else:
            new_message_id = await send_ticket_message(channel)
            save_message_id(new_message_id)

@bot.event
async def on_interaction(interaction: disnake.Interaction):
    if isinstance(interaction.component, disnake.ui.Button):
        if interaction.component.label == "Создать тикет":
            await interaction.component.callback(interaction)
        elif interaction.component.label == "Закрыть тикет":
            await interaction.component.callback(interaction)
        elif interaction.component.label == "Отправить отзыв":
            await interaction.component.callback(interaction)

bot.run('MTI2OTE2NTk2OTIwOTgxOTE0Nw.GeXkck.ZFml6kGirxx7ChnS6FT-TdcGsvr3V-3kP9VCXo')
